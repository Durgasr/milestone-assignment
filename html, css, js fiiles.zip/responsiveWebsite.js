let pEl = document.getElementById("p1");

let buttonEl = document.getElementById("btn");
let showHide = false;

function buttonClick() {
    pEl.textContent = "Hard work is the key to both success and self-satisfaction. When we do hard work, we can achieve our goals, which leads to self-satisfaction. We must always remember that positivity and motivation come from hard work. When you work hard, you come one step closer to your dreams, and that gives you positivity.They are: Determination, Skill, Passion, Discipline And Luck. Determination is necessary but, like each of the 5 keys, not sufficient for success.There is never any short cuts to success, but hard work complimented with the desire to achieve, determination, and always being motivated to get after your goal, it makes success becomes bigger. Hard work only works as hard as you do, and the level of success reached will only be as high as an individuals work level. Success is the goal of everyone's life. Life is full of challenges and opportunities but only for those people who really struggle to achieve opportunities and face the challenges. Hard work and dedication are the only spells of success. Without enthusiasm and hard work, no one can achieve success Real success in life is achieving the goals that matter to you the most. Based on the way your personality developed and the life experiences you have been through since you were born certain certain things will become important to you. Those things should define your goals and mission in life";

    pEl.classList.toggle("d-none");

    if (showHide === false) {
        buttonEl.textContent = "+";
        buttonEl.classList.add("btn-style");
        showHide = true;
    } else {
        buttonEl.textContent = "-";
        showHide = false;
    }
}